"""
Test package for Diagnostic Code Assistant backend.
"""
