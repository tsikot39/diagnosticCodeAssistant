"""Core module for application configuration and utilities."""
